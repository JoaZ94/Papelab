package co.edu.unab.papelabapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PapelabApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
